var app = angular.module("loggerApp", []);
